#!/bin/bash


./gradlew clean test -q --no-daemon