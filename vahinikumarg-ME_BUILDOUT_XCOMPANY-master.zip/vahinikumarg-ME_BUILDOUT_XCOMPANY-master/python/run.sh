#!/bin/bash

python3 -m xcompany INPUT_FILE=sample_input/input2.txt OUTPUT_FILE=out.txt